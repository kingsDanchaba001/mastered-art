----Cancellation Rate per City----
SELECT 
    pickup_city,
    COUNT(CASE WHEN status ILIKE 'cancelled%' THEN 1 END) AS cancelled_rides,
    COUNT(*) AS total_rides,
    ROUND(
        COUNT(CASE WHEN status ILIKE 'cancelled%' THEN 1 END)::numeric / COUNT(*) * 100, 
        2
    ) AS cancellation_rate_percent
FROM rides_raw
WHERE request_time BETWEEN '2021-06-01' AND '2024-12-31'
GROUP BY pickup_city
ORDER BY cancellation_rate_percent DESC
LIMIT 1;  -- highest cancellation rate city