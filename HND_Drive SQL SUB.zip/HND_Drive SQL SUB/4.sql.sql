---Top 5 Consistent Drivers----
WITH driver_activity AS (
    SELECT 
        d.driver_id,
        d.name AS driver_name,
        COUNT(r.ride_id) AS total_rides,
        DATE_PART('month', AGE(MAX(r.request_time), d.signup_date)) AS active_months
    FROM drivers_raw d
    JOIN rides_raw r ON d.driver_id = r.driver_id
    WHERE r.request_time BETWEEN '2021-06-01' AND '2024-12-31'
    GROUP BY d.driver_id, d.name, d.signup_date
)
SELECT 
    driver_name,
    total_rides,
    active_months,
    ROUND((total_rides / NULLIF(active_months, 0))::numeric, 2) AS avg_rides_per_month
FROM driver_activity
ORDER BY avg_rides_per_month DESC
LIMIT 5;