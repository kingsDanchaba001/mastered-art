---Top 3 Drivers in Each City by Total Revenue (June 2021 � Dec 2024)----
WITH driver_revenue AS (
    SELECT 
        d.driver_id,
        d.name AS driver_name,
        r.pickup_city,
        SUM(p.amount) AS total_revenue
    FROM rides_raw r
    JOIN drivers_raw d ON r.driver_id = d.driver_id
    JOIN payments_raw p ON r.ride_id = p.ride_id
    WHERE r.request_time BETWEEN '2021-06-01' AND '2024-12-31'
    GROUP BY d.driver_id, d.name, r.pickup_city
)
SELECT *
FROM (
    SELECT 
        pickup_city,
        driver_name,
        total_revenue,
        RANK() OVER (PARTITION BY pickup_city ORDER BY total_revenue DESC) AS rank
    FROM driver_revenue
) ranked
WHERE rank <= 3
ORDER BY pickup_city, rank;
