----Who Signed Up in 2021 and Still Took Rides in 2024----
SELECT 
    COUNT(DISTINCT r.rider_id) AS active_2021_riders
FROM riders_raw r
JOIN rides_raw rd ON r.rider_id = rd.rider_id
WHERE EXTRACT(YEAR FROM r.signup_date) = 2021
  AND EXTRACT(YEAR FROM rd.request_time) = 2024;
