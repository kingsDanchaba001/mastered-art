--- Drivers Bonus Qualification (Top 10)---

WITH driver_stats AS (
    SELECT 
        d.driver_id,
        d.name AS driver_name,
        COUNT(r.ride_id) AS total_rides,
        AVG(d.rating) AS avg_rating,
        ROUND(
            COUNT(CASE WHEN r.status ILIKE 'cancelled%' THEN 1 END)::numeric / COUNT(*) * 100,
            2
        ) AS cancellation_rate
    FROM drivers_raw d
    JOIN rides_raw r ON d.driver_id = r.driver_id
    WHERE r.request_time BETWEEN '2021-06-01' AND '2024-12-31'
    GROUP BY d.driver_id, d.name
)
SELECT *
FROM driver_stats
WHERE total_rides >= 30
  AND avg_rating >= 4.5
  AND cancellation_rate < 5
ORDER BY total_rides DESC
LIMIT 10;
