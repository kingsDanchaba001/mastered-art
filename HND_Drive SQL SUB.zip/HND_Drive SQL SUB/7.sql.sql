---10 Rides but Never Paid with Cash----
SELECT 
    r.rider_id,
    rd.name AS rider_name,
    COUNT(DISTINCT r.ride_id) AS total_rides
FROM rides_raw r
JOIN riders_raw rd ON r.rider_id = rd.rider_id
JOIN payments_raw p ON r.ride_id = p.ride_id
WHERE r.request_time BETWEEN '2021-06-01' AND '2024-12-31'
GROUP BY r.rider_id, rd.name
HAVING COUNT(DISTINCT r.ride_id) > 10
   AND SUM(CASE WHEN LOWER(p.method) = 'cash' THEN 1 ELSE 0 END) = 0
ORDER BY total_rides DESC;
;
