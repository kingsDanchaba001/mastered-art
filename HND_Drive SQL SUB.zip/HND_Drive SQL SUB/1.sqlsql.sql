---BUSINESS QUESTIONS---
---Top 10 Longest Rides (by distance)---
SELECT 
    r.ride_id,
    d.name AS driver_name,
    rd.name AS rider_name,
    r.pickup_city,
    r.dropoff_city,
    r.distance_km,
    p.method AS payment_method
FROM rides_raw r
JOIN drivers_raw d ON r.driver_id = d.driver_id
JOIN riders_raw rd ON r.rider_id = rd.rider_id
LEFT JOIN payments_raw p ON r.ride_id = p.ride_id
WHERE r.request_time BETWEEN '2021-06-01' AND '2024-12-31'
ORDER BY r.distance_km DESC
LIMIT 10;

