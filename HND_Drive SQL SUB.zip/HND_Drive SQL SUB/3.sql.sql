
  ---Quarterly Revenue Comparison----
  WITH revenue_quarters AS (
    SELECT 
        EXTRACT(YEAR FROM paid_date) AS year,
        EXTRACT(QUARTER FROM paid_date) AS quarter,
        SUM(amount) AS total_revenue
    FROM payments_raw
    WHERE paid_date BETWEEN '2021-06-01' AND '2024-12-31'
    GROUP BY year, quarter
)
SELECT 
    year, 
    quarter, 
    total_revenue,
    ROUND(
        (total_revenue - LAG(total_revenue) OVER (PARTITION BY quarter ORDER BY year))
        / NULLIF(LAG(total_revenue) OVER (PARTITION BY quarter ORDER BY year), 0) * 100,
        2
    ) AS yoy_growth_percent
FROM revenue_quarters
ORDER BY year, quarter;
